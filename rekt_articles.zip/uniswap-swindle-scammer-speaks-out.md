---
title: Uniswap Swindle - Scammer Speaks Out
date: 10/12/2020
tags:
  - scam
  - interview
excerpt: The following interview was conducted late last night by Inspector Rekt and an anonymous source.
banner: https://raw.githubusercontent.com/RektHQ/Assets/main/images/2020/10/banner-7.jpg
---

![](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2020/10/banner-7.jpg)

**Transactions clog the chain like a blocked up sink.** 

Must be some new yield farm opened up downtown. 

I clear my cache and light another cigarette.

Even 1000 gwei can’t calm my nerves. 

Another sleepless night, another rug pulled in Uniswap city.

_The following interview was conducted late last night by Inspector Rekt and an anonymous source._

**Take me back to the beginning, when did all this start?**

So several months ago, this is before Yam, Sushi, hell this was before CRV, I came across a few channels that broadcasted new Uniswap listings, tokens etc and kind of just researched a few of them each day, most were bogus/scams it seemed like, stealing maybe a few hundred bucks etc

stupid shit like jam.finance or similar

back then people were foaming at the mouth about the latest and greatest next project, and fomoing into everything

so, i wanted to see if i could do better, and how much better

I went to coinmechanic.io and made an erc token, not just any token, but something I thought people would see and instantly fomo into. I created a website to match fake white papers, fake audits, fake staking pools, everything. I had the coin logo done for me using fiverr etc.

**You made fake whitepapers?**

I just grabbed a posted white paper off another site and literally just half assed changed it to my token. Took about 5 mins or less

**and the audits?**

Literally just said it was in process and out a completion date

Honestly have no idea if people even went to my site but was trying to make it seem as legit as possible

**OK, and the discord, telegram groups you made, did many people join?**

Yes, not many, though I did answer questions. I didn’t inflate numbers with bots or anything.

The links were all legit but the more information people could obtain the easier they could tell this thing was bogus so it was more to make people think they were early and give the project legitimacy

anyway, i launched that shit with 100000 coins/40 eth on uni

long story short, 3 days later, there was 70k in there

so not only had it worked, it worked too well and i instantly felt like a piece of shit

i couldn't simply return peoples money so i have left it open

there is under 10k in there now, but still not everyone has pulled out their money which is insane to me

yes i could have pulled the entire thing, but it ended up being funded just way too much by people that did 0 research, but literally just couldn't miss an opportunity

i did 0 marketing, 0 listings nothing, it literally just launched on the uni and discord channels automatically with their bots, and that was it

anyway i'll give you the token name when everyone is finally out, which 4 months later, is going fucking slowly

so yeah lesson learned there

nothing like this would work now as people are like skeptical of everything which is good

but man you know how it was several months ago

we were going into shit blind every day lol

so this was early, and like i said, not mind blowing or anything, but just went the extra mile to make it look legit

and use a name that people would relate to a premium product

and be frothing at the mouth so much they couldn't afford to dyor

which is what happened apparently

i actually created 3 tokens

only launched one

one was FED

united states federal digital asset token and another was iTOKEN

apple's "token"

the third is the one i launched

but anyway

felt horrible doing that

i got into trouble early on in my late teens

which involved taking money from people illegally so

i said i wouldn't do it again, but damn, i fought some demons man

seeing a new suv sitting there for the taking

so in a way, it was the ultimate test for me

but scary to think this has probably happened to people

well, def happened to people

yeah, the guilt is the issue i would have had, and i just lay awake at night thinking about shit already, this would have been on my mind every night so thankfully, i didn't execute and take advantage of people though i still cost them gas and missed opportunity i suppose

so yeah, i'm still a piece of shit

**Did you have an exit planned out before money entered the contract**

believe it or not, i wanted to see if it would work if executed on a more professional level, i thought if it got up to a few eth i'd consider it successful, but wasn't planning on taking money

when it went up that high

i'll be honest, i did cash out some, but conscious got the better of me

and i sold it back

then i thought about it again, taking everything

so it was fucking miserable a few nights

as i just thought about this, tried to justify taking it

then i'd go back and forth

well it ended up being a morality litmus test

when it got up that high, just didn't expect that

**how high?**

Around 75k

**that wouldn't have even made the news at the time, there were so many scams going on**

Def not but it would have changed some people's lives for the worse

including mine eventually

**what % of your portfolio would that 75k have represented?**

at the time, like 1/2

**a considerable amount for you then.**

well like i said, i would have bought the wife a new car with it, she deserves it so made it even harder

and honestly, if i hadn't gotten in trouble earlier on in life

i probably would have done it

but i just knew the guilt would be impossible to deal with

**what was it about your past experience that deterred you from taking the money this time**

that was something a bit different

I don’t know if you remember WAREZ? basically ftc fraud and computer crimes 3rd degree,

ftc fraud is financial transaction card fraud

credit card fraud

i was basically buying stolen numbers

and using them to make purchases at best buy back in the day

computers

sending them to vacant houses

and selling them

**how long did that go on for?**

About a year, before I got extremely greedy, eventually, got caught b/c i missed a delivery, and signed for the package at fed ex

greed man

Greed led to a 3rd degree charge for computer crimes

**do you think it was more of a moral dilemma this time rather than a fear of the law?**

back then, legal

now, moral

since we're tech in a "safe space"

well, safer in that it's extremely anonymous

**what gave you the idea?**

**how did you create the tokens?**

i tracked down this channels that released new token launches

people monitored them including me

for everyone that was in there

**creating 3 different tokens, that doesn't sound like just an innocent experiment**

well the only reason there were 3 is b/c i fucked up a couple

in regards to tokens minted etc

for example, i only minted like 10k tokens the first time

which wasn't enough

the second one i somehow put on a diff network

so didn't set out to make 3

just kind of fucked 2 up lol

i used coinmechanic though

you can do all kinds of stuff there from simple to more sophisticated but this just needed to be a good name with decent liquidity

that is why i dumped so many eth in there initially

which i was nervous about for sure

but yeah i think part of me knew that if this worked, i'd be tempted

hell i've been tempted about other things since those charges 20 years ago

but that has always been at the back of my mind

just the wife

who yelled at me pretty much

**you told her?**

she reads me pretty well anyway, knew something was bothering me

she knows about a lot of this stuff but doesn't understand most of it

she'll ask me how yfi is doing shit like that

**don't ask 😅**

ha not lately yeah

i mean i told her what i told you basically in a lot less detail

not that i was hiding it, just didn't matter

but yeah, wasn't happy

just kind of gave m the disappointed glance and asked why

which cut deep

**I can imagine.**

**so the money was sitting there and you said you could take it if you wanted**

so yeah i minted a shitload of tokens and basically set the price

so when the money went in, i would have just dumped the tokens i was holding

but also what was interesting is

i was watching it

you would see people, the same person

put money in

and then either realize something wasn't right, or change their mind or whatever

and pull it out like 3 mins, 10 mins, however much longer later

same address, same amount

the largest transaction was about 10k

**what was the average deposit?**

if i had to guess, a few hundred bucks

**that must have added to the guilt**

which is crazy when you think about it

b/c that many people fomo'd into this thing

and you know 200 bucks was a lot to some of these people at the very least so

**what did you do to make the coin seem legitimate?**

**are the websites still up?**

honestly, i don't know that these people even visited the website

but, did the telegram discord links, fake twitter posts

fake staking pools that were "coming soon"

fake white paper with names changed

and fake audits

**anonymous devs?**

ha def

anyone that knew anything would immediately have known it was a scam i'm sure

but imagine 4 or 5 months ago

thinking for example the US had their own token that was coming out soon

**can you send a link to one of them?**

let me see if i can find FED

shit my timeline is off, says this was 60 days ago

**defi time**

so this token was still tech created

so people went into it lol

but i left it, never pulled anything out etc

[https://etherscan.io/token/0xF53c22eEC1297F0af9d4793F9985ad1B8ac2F317](https://etherscan.io/token/0xF53c22eEC1297F0af9d4793F9985ad1B8ac2F317)

looks like one other person bought it, and sold it back

**and did you make a website for this?**

na, not for this one

or the other, just the one i "launched"

**can I see that site?**

oh the site, Telegram, Discord, everything all taken down

b/c people were still buying the shit for some reason

I haven't told or shared this with anyone

I think i'm the only one technically since I have the bulk of the tokens, they can trade back their tokens for what they put in technically

**did you use the same wallet for each?**

no, i was super sketched about it and didn't want to risk anything

**how did you fund the wallets**

just sent the tokens and eth to another address on meta

this is the other

[https://etherscan.io/token/0x02fEb15a3B9d2b97010fD98D96bD4dc657C176a8](https://etherscan.io/token/0x02fEb15a3B9d2b97010fD98D96bD4dc657C176a8)

**didn't you use tornado cash?**

No it wasn't that sophisticated lol

**so there's a link**

yeah on those two

i believe it has my wallet address

**so can't publish them?**

but the token i used and launched

is a diff address

these two were just fuck ups

**and that other address still has money in it?**

yeah for now, hoping it will be empty or close soon

it just sucks b/c it's not like you can issue refunds you know

they have to do that themselves

**well you didn't take the money did you?**

No

**so I guess nobody will be angry?**

Right

---

Be careful out there you filthy degens...  Don’t get rekt...
