---
title: rekt:TV - Hopium Diaries - Dystopian Dreams
date: 05/24/2021
tags:
  - hopium diaries
  - rektTV
excerpt: Follow our anonymous author into a future of finance. Not one that will be but one that might be. 

banner: https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/05/hopium-dd-header.png
---
![](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/05/hopium-dd-header.png) 

**Follow our anonymous author into a future of finance. Not one that will be but one that might be.**

First [published](https://www.rekt.news/hopium-diaries-dystopian-dreams/) in October of 2020, the Hopium Diaries paint a picture of how cryptocurrency and decentralised finance will change the world.

We spent months working on this production to encapsulate our vision, so that we could present it to you; our reader, and so that you may share it across the world.

We have also provided carefully written subtitles in French, Spanish, Chinese and Russian, as we will soon launch the fully translated archives and fresh articles of [rekt.news](https://www.rekt.news/). 

_Is it unrealistic to predict such change?_

**Only time will tell.**

[![Hopium Diaries - Dystopian Dreams](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/05/hopium-dd-thumb-copy.png)](https://youtu.be/0ehoweA-a08?si=vQGfhaowxUk996l2)

![](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/03/rekt-text-linebreak.png) 

