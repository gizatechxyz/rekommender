---
title: REKT:TV - Ape Tax
date: 12/03/2021
tags:
  - ape tax
  - rektTV
excerpt: Ape Season is here, and Ape Tax must be paid. Just as relevant as when it was first published in December of 2020, our second major video release is an animated assessment of our online gambling culture.
banner: https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/12/apetaxyoutube-header.png
---
![](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/12/apetaxyoutube-header.png)
_Now don’t try to kid me man cub, I made a deal with you._

Four billion years have passed since we first emerged from the primordial soup, and now a new evolution has begun.

**Ape Season is here, and Ape Tax must be paid.**

_This digital darwinism takes place over blocks rather than millennia._

Just as relevant as when it was [first published in December of 2020](https://rekt.news/ape-tax/), our second major video release is an animated assessment of our online gambling culture.

Subtitles are available in various languages, and more will be added soon.

>[If you enjoy our content, please donate to our Gitcoin Grant.](https://gitcoin.co/grants/1632/rektnews-the-dark-web-of-defi-journalism)

[![](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/12/apetaxyoutube-play.png)](https://youtu.be/NwG8PjxUb78?si=F5cUlxICd_2Log1W "Ape Tax")

>You see it’s true, an ape like me, can learn to be like someone like you

![](https://raw.githubusercontent.com/RektHQ/Assets/main/images/2021/12/apetaxyoutube-conc.png)

